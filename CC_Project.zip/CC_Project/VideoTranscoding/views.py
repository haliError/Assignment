from flask import Blueprint, render_template, request, session, redirect, url_for, send_file
from MyDatabaseLib import MyDB
from MyFiles import Files
import ffmpeg

# Use of blue print to group routes, 
# name - first argument is the blue print name 
# import name - second argument - helps identify the root url for it 
mainbp = Blueprint('main', __name__)

# This function is called while accessing the root path of website
@mainbp.route('/')
def index():
    return render_template('index.html')
 
# POST methos is used from the calling login page. 
@mainbp.route('/login', methods = ['GET', 'POST'])
def login():

    #retrieve the values from environment variables of email_address and password variables
    email = request.values.get("email")
    passwd = request.values.get("pwd")

    if(email == None and passwd == None):
        return render_template('login.html')

#    print (f"Email: {email}\nPassword: {passwd}")

    # All users' email_address and passwords are extracted from the database in the form of dictionary as following.
    #  
    #    users_passwords = {"mohsinlabs@yahoo.com": "mali","hali.wahvillage@gmail.com": "hali"}
    users_passwords = MyDB.get_users_data()

    #If user password is not authenticated from the database then call the login page again.
    if(users_passwords[email] != passwd):
        return render_template('login.html')

    # Login Successful. Save the user's email_address in session.
    session['email'] = email
        
    #Redirect to video_transcoder web page
    return redirect(url_for('main.video_transcoder'))


#This function is called to covert mp4 to mov format.
@mainbp.route('/video_transcoder')
def video_transcoder():
    if 'email' in session:
        email_address = session['email']
        user_files = MyDB.get_users_files(email_address)
#        return render_template('video_transcoder.html', files=[file[0] for file in files])
        return render_template('video_transcoder.html', files = user_files, email_address = email_address )
    else:
        return redirect(url_for('main.index'))

#This function is called to covert mp4 to wav format.
@mainbp.route('/video_transcoder2')
def video_transcoder2():
    if 'email' in session:
        email_address = session['email']
        user_files = MyDB.get_users_files(email_address)
#        return render_template('video_transcoder.html', files=[file[0] for file in files])
        return render_template('video_transcoder2.html', files = user_files, email_address = email_address )
    else:
        return redirect(url_for('main.index'))

#This function is called to covert mp4 to mp3 format.
@mainbp.route('/video_transcoder3')
def video_transcoder3():
    if 'email' in session:
        email_address = session['email']
        user_files = MyDB.get_users_files(email_address)
#        return render_template('video_transcoder.html', files=[file[0] for file in files])
        return render_template('video_transcoder3.html', files = user_files, email_address = email_address )
    else:
        return redirect(url_for('main.index'))

#Logout function is called from client
@mainbp.route('/logout')
def logout():
    if 'email' in session:
        session.pop('email')

    return redirect(url_for('main.index'))

#This function is called to upload the file to convert mp4 into mov format.
@mainbp.route('/upload', methods=['POST'])
def upload_file():
    if 'videoFile' not in request.files:
        return redirect(request.url)

    file = request.files['videoFile']

    if file.filename == '':
        return redirect(request.url)

    if file and file.filename.endswith('.mp4'):

        email_address = session['email']
        s_file = file.filename

        s_file_path = Files.get_source_file_path(email_address, s_file)
        file.save(s_file_path)

        d_file = s_file.replace('.mp4','.mov')
        d_file_path = Files.get_destination_file_path(email_address, d_file)

        #ffmpeg module converts the mp4 file into mov format.
        x1 = ffmpeg.input(s_file_path).output(d_file_path).run()

        # Save the file info to the database
        MyDB.update_users_files(email_address, s_file, d_file)
        return redirect(url_for('main.video_transcoder'))
    else:
        return redirect(request.url)

#This function is called to upload the file to convert mp4 into wav format.
@mainbp.route('/upload2', methods=['POST'])
def upload_file2():
    if 'videoFile' not in request.files:
        return redirect(request.url)

    file = request.files['videoFile']

    if file.filename == '':
        return redirect(request.url)

    if file and file.filename.endswith('.mp4'):

        email_address = session['email']
        s_file = file.filename

        s_file_path = Files.get_source_file_path(email_address, s_file)
        file.save(s_file_path)

        d_file = s_file.replace('.mp4','.wav')
        d_file_path = Files.get_destination_file_path(email_address, d_file)

        #ffmpeg module converts the mp4 file into wav format.
        x1 = ffmpeg.input(s_file_path).output(d_file_path).run()

        # Save the file info to the database
        MyDB.update_users_files(email_address, s_file, d_file)
        return redirect(url_for('main.video_transcoder2'))
    else:
        return redirect(request.url)

#This function is called to upload the file to convert mp4 into mp3 format.
@mainbp.route('/upload3', methods=['POST'])
def upload_file3():
    if 'videoFile' not in request.files:
        return redirect(request.url)

    file = request.files['videoFile']

    if file.filename == '':
        return redirect(request.url)

    if file and file.filename.endswith('.mp4'):

        email_address = session['email']
        s_file = file.filename

        s_file_path = Files.get_source_file_path(email_address, s_file)
        file.save(s_file_path)

        d_file = s_file.replace('.mp4','.mp3')
        d_file_path = Files.get_destination_file_path(email_address, d_file)

        #ffmpeg module converts the mp4 file into mp3 format.
        x1 = ffmpeg.input(s_file_path).output(d_file_path).run()

        # Save the file info to the database
        MyDB.update_users_files(email_address, s_file, d_file)
        return redirect(url_for('main.video_transcoder3'))
    else:
        return redirect(request.url)

#This function is called to download the original file.
@mainbp.route('/download_source/<filename>')
def download_source_file(filename):

    #Extract the email address from session
    email_address = session['email']

    #Get the absolute path of source file to download
    file_path = Files.get_source_file_path(email_address, filename)
    return send_file(file_path, as_attachment=True)


#This function is called to download the transcoded file.
@mainbp.route('/download_destination/<filename>')
def download_destination_file(filename):

    #Extract the email address from session
    email_address = session['email']
    #Get the absolute path of transcoded file to download
    file_path = Files.get_destination_file_path(email_address, filename)
    return send_file(file_path, as_attachment=True)
